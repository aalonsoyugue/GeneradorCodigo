//Función Sumar


print("Introducir el valor para A:")
A = input()

print("Introducir el valor para B:")
B = input()

C = Suma(int(A), int(B))

print("El resultado es: ", C)


def Suma(A, B):
	return A + B