//Función Repetir


print("Introducir el valor para A:")
A = input()

print("Introducir el valor para B:")
B = input()

C = Suma(int(A), int(B))

print("El resultado es: ", C)


def Repetir(A, B):
	return A + B
	
	
	
	/**		PARTE ADRIANA		
	
		la función recibe un parámetro, que será un número o la condición, por lo que repetir será
		
		
		
		def Repetir(param1):
		
			if (esNumero(param1)) {
				for (int i = 0; i < param1; i++) {
					//Aquí mediante Java escribiremos la otra función, que será sumar, multiplicar...
					
				}
			} else {
				while (param1){
					//Aquí mediante Java escribiremos la otra función, que será sumar, multiplicar...
				}
			}
			
			
		def esNumero(param1):
		
			switch (param1) {
				case 0: return true: break;
				case 1: return true: break;
				case 2: return true: break;
				case 3: return true: break;
				case 4: return true: break;
				case 5: return true: break;
				case 6: return true: break;
				case 7: return true: break;
				case 8: return true: break;
				case 9: return true: break;
				default: return false; break;
				}
				
				
				
		def definirSigno(A, B):
			
			if A >= 0 && B >= 0
				return "+"
			if A >= 0 && B < 0
				return "-"
			if A < 0 && B >= 0
				return "-"
			if A < 0 && B < 0
				return "-"
		
		
		
			
	